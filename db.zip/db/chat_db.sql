-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Авг 18 2020 г., 21:41
-- Версия сервера: 10.4.13-MariaDB
-- Версия PHP: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `chat_db`
--

-- --------------------------------------------------------

--
-- Структура таблицы `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `user_id_1` int(11) NOT NULL,
  `user_id_2` int(11) NOT NULL,
  `text` text NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `messages`
--

INSERT INTO `messages` (`id`, `user_id_1`, `user_id_2`, `text`, `time`) VALUES
(5, 1, 3, 'Nunc maximus justo eget lobortis vulputate.', '0000-00-00 00:00:00'),
(6, 3, 1, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', '0000-00-00 00:00:00'),
(7, 2, 1, 'Fusce ornare, ligula non condimentum posuere', '0000-00-00 00:00:00'),
(8, 1, 2, 'lorem eros molestie odio, et scelerisque nisl justo et orci', '0000-00-00 00:00:00'),
(9, 2, 1, 'Curabitur eget tellus quis mauris consequat laoreet.', '0000-00-00 00:00:00'),
(10, 1, 2, 'Nunc maximus justo eget lobortis vulputate.', '0000-00-00 00:00:00'),
(11, 3, 1, 'sdfsdfsdfsdfsdfs', '2020-08-14 23:17:43'),
(12, 16, 6, 'Hello', '2020-08-15 23:36:17'),
(13, 16, 6, 'test', '2020-08-16 15:39:09'),
(14, 16, 5, 'test\r\n', '2020-08-16 15:44:05'),
(15, 16, 7, 'dasd', '2020-08-18 06:42:00'),
(16, 16, 7, 'dasda', '2020-08-18 06:51:01'),
(17, 16, 7, 'ouio', '2020-08-18 06:56:38'),
(19, 16, 7, 'fffffff', '2020-08-18 07:14:37'),
(20, 16, 7, 'aaaa', '2020-08-18 07:17:40'),
(21, 16, 7, 'ssss', '2020-08-18 07:17:44'),
(22, 16, 7, 'ddd', '2020-08-18 07:17:47'),
(23, 16, 4, 'fsdf', '2020-08-18 19:08:50'),
(24, 16, 3, 'fdf', '2020-08-18 19:09:03'),
(25, 16, 8, 'd', '2020-08-18 19:09:17'),
(26, 16, 9, 'gh\n', '2020-08-18 19:12:25'),
(27, 16, 1, 'dsdsd', '2020-08-18 22:04:04');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
